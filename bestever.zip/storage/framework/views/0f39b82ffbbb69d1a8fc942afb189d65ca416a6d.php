                

<?php $__env->startSection('main_content'); ?>

  <!-- START MAIN -->
  <div id="main">
      <!-- START WRAPPER -->
      <div class="wrapper">         

          <!-- //////////////////////////////////////////////////////////////////////////// -->

          <!-- START CONTENT -->
          <section id="content">

              <!--start container-->
              <div class="container">

                  <!--card widgets start-->
                  <div id="card-widgets">
                    <div class="row" style="display: none;">
                      <!-- map-card -->
                      <div class="col s12 m12 l4">
                          <div class="map-card">
                              <div class="card">
                                  <div class="card-image waves-effect waves-block waves-light">
                                      <div id="map-canvas" data-lat="40.747688" data-lng="-74.004142"></div>
                                  </div>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>  

                <div class="container">
                  <div class="row">
                    <div class="col s12 m12 l12">
                      <h5 class="breadcrumbs-title">Payout Statement</h5>
                      <ol class="breadcrumbs">
                        <li><a href="index.html">Dashboard</a>
                        </li>
                        <li><a href="#">Payout Statement</a>
                        </li>
                        <li class="active">Growth Withdrawal</li>
                      </ol>
                    </div>
                  </div>
                </div>

           <!--DataTables example-->
            <div id="table-datatables">
              <div class="row">
                <div class="col s12 m8" style="align-content: center;">
                  <form class="col s12" method="post" action="<?php echo e(url('/')); ?>/admin/growth_withdrawal_process" data-parsley-validate="">
                    <?php echo e(csrf_field()); ?>

                      <table id="data-table-simple1" class="responsive-table display" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Growth Income</th>
                                <th>00.00</th>
                                <th><input type="text" id="growth_income" name="growth_income" placeholder="Enter Amount" data-parsley-required="true"></th>
                            </tr>
                        </thead>
                        <thead>
                            <tr>
                                <th>Rejection Penalty</th>
                                <th>00.00</th>
                                <th><input type="text" id="rejection_penalty" name="rejection_penalty" placeholder="Enter Amount" data-parsley-required="true"></th>
                            </tr>
                        </thead>
                        <thead>
                            <tr>
                                <th></th>
                                <th>Total Amount</th>
                                <th width="30%"><input type="text" id="total_amount" name="total_amount" placeholder="Enter Amount" data-parsley-required="true"></th>
                            </tr>
                        </thead>
                        <thead>
                            <tr>
                                <th></th>
                                <th></th>
                                <th width="30%"> <input type="submit" class="btn cyan waves-effect waves-light right" id="submit" name="submit"></th>
                            </tr>
                        </thead>
                      </table>
                  </form>
                </div>
              </div>
            </div> 
            <br>
            <div class="divider"></div> 
          
            <!--end container-->
          </section>
          <!-- END CONTENT -->

      </div>
      <!-- END WRAPPER -->

  </div>
  <!-- END MAIN -->
   

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>