                

<?php $__env->startSection('main_content'); ?>

  <!-- START MAIN -->
  <div id="main">
      <!-- START WRAPPER -->
      <div class="wrapper">         

          <!-- //////////////////////////////////////////////////////////////////////////// -->

          <!-- START CONTENT -->
          <section id="content">

              <!--start container-->
              <div class="container">

                  <!--card widgets start-->
                  <div id="card-widgets">
                    <div class="row" style="display: none;">
                      <!-- map-card -->
                      <div class="col s12 m12 l4">
                          <div class="map-card">
                              <div class="card">
                                  <div class="card-image waves-effect waves-block waves-light">
                                      <div id="map-canvas" data-lat="40.747688" data-lng="-74.004142"></div>
                                  </div>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>  

                <div class="container">
                  <div class="row">
                    <div class="col s12 m12 12">
                      <h5 class="breadcrumbs-title">New joining</h5>
                      <ol class="breadcrumbs">
                        <li><a href="index.html">Dashboard</a>
                        </li>
                        <li><a href="#">Account</a>
                        </li>
                        <li class="active">New joining</li>
                      </ol>
                    </div>
                  </div>
                </div>

                <?php
                  $user_status = Sentinel::check();
                ?>

            <div id="basic-form" class="section">
              <div class="row">
                <div class="col s12 m12 8">
                  <div class="card-panel">
                    <h4 class="header2">New joining</h4>
                    <div class="row">
                      <form class="col s12" method="post" action="<?php echo e(url('/')); ?>/admin/joining_process" data-parsley-validate="">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                          <div class="input-field col s12">
                            <input id="user_id" name="user_id" type="email" data-parsley-required="true">
                            <label for="user_id">User Id(Email)</label>
                          </div>
                        </div>
                        <div class="row">
                          <div class="input-field col s12">
                            <input id="password" name="password" type="password" data-parsley-required="true">
                            <label for="password">Password</label>
                          </div>
                        </div>
                        <div class="row">
                          <div class="input-field col s12">
                            <input id="spencer_id" name="spencer_id" onchange="sponcer_name()" type="text" value="<?php echo e(isset($user_status->id) ? $user_status->id : ''); ?>" data-parsley-required="true" >
                            <label for="spencer_id">Spencer Id</label>
                          </div>
                        </div>
                        <div class="row">
                          <div class="input-field col s12">
                            <input id="spencer_name" name="spencer_name" type="text" value="<?php echo e(isset($user_status->user_name) ? $user_status->user_name : ''); ?>" data-parsley-required="true" readonly="">
                            <label for="spencer_name">Spencer Name</label>
                          </div>
                        </div>
                        <div class="row">
                          <div class="input-field col s12">
                            <input id="username" name="username" type="text" data-parsley-required="true">
                            <label for="username">Applicant Name</label>
                          </div>
                        </div>
                        <div class="row">
                          <div class="input-field col s12">
                            <input id="mobile" name="mobile" type="text" data-parsley-required="true">
                            <label for="mobile">Mobile</label>
                          </div>
                        </div>
                        <div class="row">
                          <div class="input-field col s12">
                            <select id="package" name="package" data-parsley-required="true">
                              <option value="">Select Package</option>
                              <option value="1000">1000</option>
                              <option value="2000">2000</option>
                              <option value="3000">3000</option>
                              <option value="4000">4000</option>
                              <option value="5000">5000</option>
                              <option value="10000">10000</option>
                              <option value="15000">15000</option>
                              <option value="20000">20000</option>
                              <option value="25000">25000</option>
                            </select>
                            <label for="package">Package</label>
                          </div>
                        </div>
                        <div class="row">
                          <div class="input-field col s12">
                            <input type="submit" class="btn cyan waves-effect waves-light right" id="submit" name="submit">
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          
            <!--end container-->
          </section>
          <!-- END CONTENT -->

      </div>
      <!-- END WRAPPER -->

  </div>
  <!-- END MAIN -->
 <script type="text/javascript">
    function sponcer_name()
    {
       var id = $('#spencer_id').val();
       $.ajax({
              url: "<?php echo e(url('/admin/get_sponcer_name')); ?>",
              type: 'POST',
              // dataType: 'default: Intelligent Guess (Other values: xml, json, script, or html)',
              data: {
                _method: 'POST',
                id     : id,
                _token:  '<?php echo e(csrf_token()); ?>'
              },
            success: function(response)
            {
                $('#spencer_name').val(response);
            }
            });
    }
  </script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>