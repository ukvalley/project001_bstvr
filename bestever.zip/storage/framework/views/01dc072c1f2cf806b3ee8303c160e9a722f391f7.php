                

<?php $__env->startSection('main_content'); ?>

  <!-- START MAIN -->
  <div id="main">
      <!-- START WRAPPER -->
      <div class="wrapper">         

          <!-- //////////////////////////////////////////////////////////////////////////// -->

          <!-- START CONTENT -->
          <section id="content">

              <!--start container-->
              <div class="container">

                  <!--card widgets start-->
                  <div id="card-widgets">
                    <div class="row" style="display: none;">
                      <!-- map-card -->
                      <div class="col s12 m12 l4">
                          <div class="map-card">
                              <div class="card">
                                  <div class="card-image waves-effect waves-block waves-light">
                                      <div id="map-canvas" data-lat="40.747688" data-lng="-74.004142"></div>
                                  </div>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>  

                <div class="container">
                  <div class="row">
                    <div class="col s12 m12 l12">
                      <h5 class="breadcrumbs-title">Payout Statement</h5>
                      <ol class="breadcrumbs">
                        <li><a href="<?php echo e(url('/customer/dashboard')); ?>">Dashboard</a>
                        </li>
                        <li><a href="#">Payout Statement</a>
                        </li>
                        <li class="active">Work Withdrawal</li>
                      </ol>
                    </div>
                  </div>
                </div>

           <!--DataTables example-->
            <div id="table-datatables">
              <div class="row">
                <input type="hidden" id="total_a" name="total_a" value="<?php echo e($level_income+$direct_income-$pre_work_withdrawal); ?>">
                <div class="col s12 m8" style="align-content: center;">
                  <form id="form" class="col s12" method="post" onsubmit="return validateForm()" action="<?php echo e(url('/')); ?>/customer/work_withdrawal_process" <?php /* data-parsley-validate="" */ ?>>
                    <?php echo $__env->make('admin.layout._operation_status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo e(csrf_field()); ?>

                      <div class="row">
                        <div class="input-field col s4">
                            <label>Level Income</label>
                        </div>
                        <div class="input-field col s4" style="float: right;">
                          <label style="color: #000;font-weight: bold;"><?php echo e($level_income); ?></label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="input-field col s4">
                            <label >Direct Income</label>
                        </div>
                        <div class="input-field col s4" style="float: right;">
                          <label style="color: #000;font-weight: bold;"> <?php echo e($direct_income); ?></label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="input-field col s4">
                            <label >Withdrawal</label>
                        </div>
                        <div class="input-field col s4" style="float: right;">
                          <label style="color: #000;font-weight: bold;"> <?php echo e($pre_work_withdrawal); ?></label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="input-field col s4">
                            <label>Total Amount</label>
                        </div>
                        <div class="input-field col s4" style="float: right;">
                          <div style="margin-left: -30%">
                            <hr style="margin-right: 55%">
                          </div>
                          <label style="color: #000;font-weight: bold;"><span style="margin-left: -5%"><i class="fa fa-inr"></i></span>  <?php echo e($level_income+$direct_income-$pre_work_withdrawal); ?></label>
                        </div>
                        <br><br><br>
                        <div class="input-field col s12">
                          <select id="total_amount" name="total_amount" data-parsley-required="true">
                              <option value="">Select Package</option>
                              <option value="1000">1000</option>
                              <option value="2000">2000</option>
                              <option value="3000">3000</option>
                              <option value="4000">4000</option>
                              <option value="5000">5000</option>
                              <option value="10000">10000</option>
                              <option value="15000">15000</option>
                              <option value="20000">20000</option>
                              <option value="25000">25000</option>
                            </select>
                            <label for="total_amount">Package</label>
                            <span id="error_total_amount" class="parsley-required"></span>
                            <span class="parsley-required"><?php echo e('Work withdrawal will be available from 28 April 2018.'); ?></span>
                         <?php /*  <input type="submit" class="btn cyan waves-effect waves-light right" id="submit" name="submit"> */ ?>
                        </div>
                      </div>
                  </form>
                </div>
              </div>
            </div> 
            <br>
            <div class="divider"></div> 
          
            <!--end container-->
          </section>
          <!-- END CONTENT -->

      </div>
      <!-- END WRAPPER -->

  </div>
  <!-- END MAIN -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function()
    {
      $("#form").submit(function()
      {
        var total_amount = $('#total_amount').val();
        var total_a      = $('#total_a').val();
        if(total_amount=='')
        {
          $('#error_total_amount').text('Please select amount');
          return false;
        }
        else if(parseInt(total_amount)>parseInt(total_a))
        { 
          $('#error_total_amount').text('Amount should not grater than total amount');
          return false;
        }
        else 
        {
          $('#error_total_amount').text('');
        }
      });
    });
  </script>
   

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>