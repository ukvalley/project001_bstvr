                

<?php $__env->startSection('main_content'); ?>

  <!-- START MAIN -->
  <div id="main">
      <!-- START WRAPPER -->
      <div class="wrapper">         

          <!-- //////////////////////////////////////////////////////////////////////////// -->

          <!-- START CONTENT -->
          <section id="content">

              <!--start container-->
              <div class="container">

                  <!--card widgets start-->
                  <div id="card-widgets">
                    <div class="row" style="display: none;">
                      <!-- map-card -->
                      <div class="col s12 m12 l4">
                          <div class="map-card">
                              <div class="card">
                                  <div class="card-image waves-effect waves-block waves-light">
                                      <div id="map-canvas" data-lat="40.747688" data-lng="-74.004142"></div>
                                  </div>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>  

                <div class="container">
                  <div class="row">
                    <div class="col s12 m12 l12">
                      <h5 class="breadcrumbs-title">Send Link1</h5>
                      <ol class="breadcrumbs">
                        <li><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a>
                        </li>
                        <li><a href="#">Send Link</a>
                        </li>
                        <li class="active">Deposite Link</li>
                      </ol>
                    </div>
                  </div>
                </div>
                
                <div id="basic-form" class="section">
                  <div class="row">
                    <div class="col s12 m12 8">
                      <?php echo $__env->make('admin.layout._operation_status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                  </div>
                </div>

           <!--DataTables example-->
            <div id="table-datatables">
              <div class="row">
                <div class="col s12 m12" style="align-content: center;">
                  <form class="col s12" method="post" action="<?php echo e(url('/')); ?>/admin/send_deposite_link" data-parsley-validate="">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="input-field col s6">
                          <select id="admin" name="admin" data-parsley-required="true">
                            <option value="">Select Admin</option>
                              <?php foreach($arr_admin_acc as $data): ?>                                
                                <option value="<?php echo e(base64_encode($data['id'])); ?>"><?php echo e($data['user_name']); ?></option>
                              <?php endforeach; ?>
                            </select>
                            <label for="admin">Admin Account</label>
                        </div>
                                                  <div class="input-field col s6">
                          <select id="user" name="user" data-parsley-required="true">
                            <option value="">Select User</option>
                            <?php foreach($arr_user_acc as $value): ?>                                
                              <option value="<?php echo e(base64_encode($value['id'])); ?>"><?php echo e($value['user_name']."(".$value['package'].")"); ?> <?php if($value['deposit_sms_link']=='1'): ?> <span>Link Sent</span>  <?php endif; ?></option>
                            <?php endforeach; ?>
                          </select>
                          <label for="user">User Account</label>
                        </div>
                        <div class="input-field col s12">
                          <input type="submit" style="float: " value="Send Link" class="btn cyan waves-effect waves-light right" id="submit" name="submit">
                        </div>
                      </div>
                  </form>
                </div>
              </div>
            </div> 
            <br>
            <div class="divider"></div> 
          
            <!--end container-->
          </section>
          <!-- END CONTENT -->

      </div>
      <!-- END WRAPPER -->

  </div>
  <!-- END MAIN -->
   

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>