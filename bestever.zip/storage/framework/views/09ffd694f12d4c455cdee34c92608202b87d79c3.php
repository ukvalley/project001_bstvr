                

<?php $__env->startSection('main_content'); ?>

  <!-- START MAIN -->
  <div id="main">
      <!-- START WRAPPER -->
      <div class="wrapper">         

          <!-- //////////////////////////////////////////////////////////////////////////// -->

          <!-- START CONTENT -->
          <section id="content">

              <!--start container-->
              <div class="container">

                  <!--card widgets start-->
                  <div id="card-widgets">
                    <div class="row" style="display: none;">
                      <!-- map-card -->
                      <div class="col s12 m12 l4">
                          <div class="map-card">
                              <div class="card">
                                  <div class="card-image waves-effect waves-block waves-light">
                                      <div id="map-canvas" data-lat="40.747688" data-lng="-74.004142"></div>
                                  </div>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>  

                <div class="container">
                  <div class="row">
                    <div class="col s12 m12 12">
                      <h5 class="breadcrumbs-title">Upload Recipient - Deposite</h5>
                      <ol class="breadcrumbs">
                        <li><a href="<?php echo e(url('/customer/dashboard')); ?>">Dashboard</a>
                        </li>
                        <li><a href="#">Activation</a>
                        </li>
                        <li class="active">Upload Recipient</li>
                      </ol>
                    </div>
                  </div>
                </div>

                <?php
                  $user_status = Sentinel::check();
                ?>

            <div id="basic-form" class="section">
              <div class="row">
                <div class="col s12 m12 8">
                  <?php echo $__env->make('admin.layout._operation_status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  <div class="card-panel">
                    <h4 class="header2">Upload Recipient - Deposite</h4>
                    <div class="row">
                      <form class="col s12" method="post" action="<?php echo e(url('/')); ?>/customer/depisite_approval_process" data-parsley-validate="" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                          <div class="input-field col s12">
                            <input id="reciever_id" name="reciever_id" onchange="sponcer_name()" type="text"  data-parsley-required="true" >
                            <label for="reciever_id">Reciever Id</label>
                          </div>
                        </div>
                        <div class="row">
                          <div class="input-field col s12">
                            <input id="reciever_name" name="reciever_name" type="text" data-parsley-required="true" readonly="">
                            <label for="reciever_name">Reciever Name</label>
                          </div>
                        </div>
                        <div class="row">
                          <div class="input-field col s12">
                            <select id="package" name="package" data-parsley-required="true">
                              <option value="<?php echo e(isset($user_status->package) ? $user_status->package : ''); ?>" selected=""><?php echo e(isset($user_status->package) ? $user_status->package : ''); ?></option>
                            </select>
                            <label for="package">Package</label>
                          </div>
                        </div>
                        <div class="file-field input-field">
                          <div class="btn">
                            <span>File</span>
                            <input type="file" id="image" name="image" multiple="" data-parsley-required="true">
                          </div>
                          <div class="file-path-wrapper">
                            <input class="file-path" type="text" placeholder="Upload one or more files" disabled="">
                          </div>
                        </div>
                        <div class="row">
                          <div class="input-field col s12">
                            <input type="submit" class="btn cyan waves-effect waves-light right" id="submit" name="submit">
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          
            <!--end container-->
          </section>
          <!-- END CONTENT -->

      </div>
      <!-- END WRAPPER -->

  </div>
  <!-- END MAIN -->
 <script type="text/javascript">
    function sponcer_name()
    {
       var id = $('#reciever_id').val();
       $.ajax({
              url: "<?php echo e(url('/customer/get_sponcer_name')); ?>",
              type: 'POST',
              // dataType: 'default: Intelligent Guess (Other values: xml, json, script, or html)',
              data: {
                _method: 'POST',
                id     : id,
                _token:  '<?php echo e(csrf_token()); ?>'
              },
            success: function(response)
            {
                $('#reciever_name').val(response);
            }
            });
    }
  </script>
<?php $__env->stopSection(); ?> 
               <?php /*  $("#reciever_name").attr("style","font-size: 0.8rem;-webkit-transform: translateY(-140%);-moz-transform: translateY(-140%);-ms-transform: translateY(-140%);-o-transform: translateY(-140%);transform: translateY(-140%);"); */ ?>
<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>