  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(url('/')); ?>/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Admin</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
           <?php /*  <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span> */ ?>
          </a>
         <?php /*  <ul class="treeview-menu">
            <li class="active"><a href="index.html"><i class="fa fa-circle-o"></i> Dashboard v1</a></li>
            <li><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>
          </ul> */ ?>
        </li>
        <li class=" treeview">
          <a class="collapsible-header waves-effect waves-cyan"><i class="fa fa-check-square"></i>Admin <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"> 
              <a href="<?php echo e(url('/')); ?>/admin/user_list" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Users List</a>
            </li>
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/work_income" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Work Income</a>
            </li>
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/link_send" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Send Link</a>
            </li>
            <li>
             <a href="<?php echo e(url('/')); ?>/admin/support" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Support</a>
            </li>
            <li>
             <a href="#" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Change Password</a>
            </li>
          </ul>
        </li>
        <li class=" treeview">
          <a class="collapsible-header waves-effect waves-cyan"><i class="fa fa-user"></i>User <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/u_daily_income" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Daily Growth</a>
            </li>
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/u_work_income" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Work Income</a>
            </li>
            <li>
             <a href="#" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Withdrawal/Transaction</a>
            </li>
            <li>
             <a href="<?php echo e(url('/')); ?>/admin/u_support" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Support</a>
            </li>
            <li>
             <a href="#" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Change Password</a>
            </li>
          </ul>
        </li>
        <li class="bold"><a href="<?php echo e(url('/')); ?>/admin/logout" class="waves-effect waves-cyan"><i class="fa fa-close"></i> Logout</a>

      </ul>
    </section>
    <!-- /.sidebar -->

  </aside>